// ReSharper disable UnusedMember.Global
// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable UnusedMethodReturnValue.Global
using System;
using Random = System.Random;
using SuppressMessage = System.Diagnostics.CodeAnalysis.SuppressMessageAttribute;
using AnimationCurve = UnityEngine.AnimationCurve;
using Transform = UnityEngine.Transform;
using Camera = UnityEngine.Camera;
using Vector3 = UnityEngine.Vector3;
using Quaternion = UnityEngine.Quaternion;
using NotNull = JetBrains.Annotations.NotNullAttribute;
using Debug = UnityEngine.Debug;
using Object = UnityEngine.Object;
using TweenType = PrimeTween.TweenAnimation.TweenType;

namespace PrimeTween {
    public partial struct Tween {
        /// <summary>Shakes the camera.<br/>
        /// If the camera is perspective, shakes all angles.<br/>
        /// If the camera is orthographic, shakes the z angle and x/y coordinates.<br/>
        /// Reference strengthFactor values - light: 0.2, medium: 0.5, heavy: 1.0.</summary>
        public static Sequence ShakeCamera(Camera camera, float strengthFactor, float duration = 0.5f, float frequency = ShakeSettings.defaultFrequency, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = PrimeTweenConfig.defaultUseUnscaledTimeForShakes) {
            if (camera == null) {
                Debug.LogError($"'{nameof(camera)}' is null");
                return default;
            }
            var transform = camera.transform;
            if (camera.orthographic) {
                float orthoPosStrength = strengthFactor * camera.orthographicSize * 0.03f;
                return Sequence.Create()
                    .Group(ShakeLocalPosition(transform, new ShakeSettings(new Vector3(orthoPosStrength, orthoPosStrength), duration, frequency, startDelay: startDelay, endDelay: endDelay, useUnscaledTime: useUnscaledTime)))
                    .Group(ShakeLocalRotation(transform, new ShakeSettings(new Vector3(0, 0, strengthFactor * 0.6f), duration, frequency, startDelay: startDelay, endDelay: endDelay, useUnscaledTime: useUnscaledTime)));
            }
            return Sequence.Create()
                .Group(ShakeLocalRotation(transform, new ShakeSettings(strengthFactor * Vector3.one, duration, frequency, startDelay: startDelay, endDelay: endDelay, useUnscaledTime: useUnscaledTime)));
        }

        public static Tween ShakeLocalPosition([NotNull] Transform target, Vector3 strength, float duration, float frequency = ShakeSettings.defaultFrequency, bool enableFalloff = true, Ease easeBetweenShakes = Ease.Default, float asymmetryFactor = 0f, int cycles = 1,
            float startDelay = 0, float endDelay = 0, bool useUnscaledTime = PrimeTweenConfig.defaultUseUnscaledTimeForShakes)
            => ShakeLocalPosition(target, new ShakeSettings(strength, duration, frequency, enableFalloff, easeBetweenShakes, asymmetryFactor, cycles, startDelay, endDelay, useUnscaledTime));
        public static Tween ShakeLocalPosition([NotNull] Transform target, ShakeSettings settings)
            => ShakeTransform(TweenType.ShakeLocalPosition, target, settings);
        public static Tween PunchLocalPosition([NotNull] Transform target, Vector3 strength, float duration, float frequency = ShakeSettings.defaultFrequency, bool enableFalloff = true, Ease easeBetweenShakes = Ease.Default, float asymmetryFactor = 0f, int cycles = 1,
            float startDelay = 0, float endDelay = 0, bool useUnscaledTime = PrimeTweenConfig.defaultUseUnscaledTimeForShakes)
            => PunchLocalPosition(target, new ShakeSettings(strength, duration, frequency, enableFalloff, easeBetweenShakes, asymmetryFactor, cycles, startDelay, endDelay, useUnscaledTime));
        public static Tween PunchLocalPosition([NotNull] Transform target, ShakeSettings settings) => ShakeLocalPosition(target, settings.WithPunch());

        public static Tween ShakeLocalRotation([NotNull] Transform target, Vector3 strength, float duration, float frequency = ShakeSettings.defaultFrequency, bool enableFalloff = true, Ease easeBetweenShakes = Ease.Default, float asymmetryFactor = 0f, int cycles = 1,
            float startDelay = 0, float endDelay = 0, bool useUnscaledTime = PrimeTweenConfig.defaultUseUnscaledTimeForShakes)
            => ShakeLocalRotation(target, new ShakeSettings(strength, duration, frequency, enableFalloff, easeBetweenShakes, asymmetryFactor, cycles, startDelay, endDelay, useUnscaledTime));
        public static Tween ShakeLocalRotation([NotNull] Transform target, ShakeSettings settings)
            => ShakeTransform(TweenType.ShakeLocalRotation,  target, settings);
        public static Tween PunchLocalRotation([NotNull] Transform target, Vector3 strength, float duration, float frequency = ShakeSettings.defaultFrequency, bool enableFalloff = true, Ease easeBetweenShakes = Ease.Default, float asymmetryFactor = 0f, int cycles = 1,
            float startDelay = 0, float endDelay = 0, bool useUnscaledTime = PrimeTweenConfig.defaultUseUnscaledTimeForShakes)
            => PunchLocalRotation(target, new ShakeSettings(strength, duration, frequency, enableFalloff, easeBetweenShakes, asymmetryFactor, cycles, startDelay, endDelay, useUnscaledTime));
        public static Tween PunchLocalRotation([NotNull] Transform target, ShakeSettings settings) => ShakeLocalRotation(target, settings.WithPunch());

        public static Tween ShakeScale([NotNull] Transform target, Vector3 strength, float duration, float frequency = ShakeSettings.defaultFrequency, bool enableFalloff = true, Ease easeBetweenShakes = Ease.Default, float asymmetryFactor = 0f, int cycles = 1,
            float startDelay = 0, float endDelay = 0, bool useUnscaledTime = PrimeTweenConfig.defaultUseUnscaledTimeForShakes)
            => ShakeScale(target, new ShakeSettings(strength, duration, frequency, enableFalloff, easeBetweenShakes, asymmetryFactor, cycles, startDelay, endDelay, useUnscaledTime));
        public static Tween ShakeScale([NotNull] Transform target, ShakeSettings settings)
            => ShakeTransform(TweenType.ShakeScale, target, settings);
        public static Tween PunchScale([NotNull] Transform target, Vector3 strength, float duration, float frequency = ShakeSettings.defaultFrequency, bool enableFalloff = true, Ease easeBetweenShakes = Ease.Default, float asymmetryFactor = 0f, int cycles = 1,
            float startDelay = 0, float endDelay = 0, bool useUnscaledTime = PrimeTweenConfig.defaultUseUnscaledTimeForShakes)
            => PunchScale(target, new ShakeSettings(strength, duration, frequency, enableFalloff, easeBetweenShakes, asymmetryFactor, cycles, startDelay, endDelay, useUnscaledTime));
        public static Tween PunchScale([NotNull] Transform target, ShakeSettings settings) => ShakeScale(target, settings.WithPunch());

        static Tween ShakeTransform(TweenType tweenType, [NotNull] Transform target, ShakeSettings settings) {
            if (PrimeTweenManager.Instance.isDestroyed) {
                return default;
            }
            var tween = PrimeTweenManager.FetchTween(settings._updateType);
            ref var rt = ref tween.managedData;
            ref var d = ref tween.data;

            prepareShakeData(settings, ref rt, ref d, target);
            var tweenSettings = settings.tweenSettings;
            tween.Setup(target, ref tweenSettings, true, tweenType, ref rt, ref d);
            return PrimeTweenManager.Animate(ref rt, ref d);
        }

        public static Tween ShakeCustom<T>([NotNull] T target, Vector3 startValue, ShakeSettings settings, [NotNull] Action<T, Vector3> onValueChange) where T : class {
            if (onValueChange == null) {
                Debug.LogError(Constants.onValueChangeNullError);
                return default;
            }
            if (PrimeTweenManager.Instance.isDestroyed) {
                return default;
            }
            var tween = PrimeTweenManager.FetchTween(settings._updateType);
            ref var rt = ref tween.managedData;
            ref var d = ref tween.data;

            d.startValue.CopyFrom(ref startValue);
            prepareShakeData(settings, ref rt, ref d, target);
            tween.customOnValueChange = onValueChange;
            var tweenSettings = settings.tweenSettings;
            tween.Setup(target, ref tweenSettings, false, TweenType.ShakeCustom, ref rt, ref d);
            tween.onValueChange = (ref TweenData rt2, ref UnmanagedTweenData d2) => {
                if (d2.isUpdating) {
                    Debug.LogError(Constants.recursiveCallError);
                    return;
                }
                d2.isUpdating = true;
                var _onValueChange = rt2.cold.customOnValueChange as Action<T, Vector3>;
                Assert.IsNotNull(_onValueChange);
                var val = d2.startValue.vector3 + getShakeVal(ref rt2, ref d2);
                try {
                    _onValueChange(rt2.target as T, val);
                } finally {
                    d2.isUpdating = false;
                }
            };
            return PrimeTweenManager.Animate(ref rt, ref d);
        }
        public static Tween PunchCustom<T>([NotNull] T target, Vector3 startValue, ShakeSettings settings, [NotNull] Action<T, Vector3> onValueChange) where T : class => ShakeCustom(target, startValue, settings.WithPunch(), onValueChange);

        static void prepareShakeData(ShakeSettings settings, ref TweenData rt, ref UnmanagedTweenData d, object target) {
            var shakeData = new ShakeData();
            shakeData.Setup(settings, ref rt, ref d, target);
            rt.cold.blob.Store(shakeData);
        }

        internal static Vector3 getShakeVal(ref TweenData rt, ref UnmanagedTweenData d) {
            var shakeData = rt.cold.blob.Load<ShakeData>();
            float frequency = shakeData.frequency; // decoded once because Mathf.HalfToFloat is a native call
            float fadeInOutFactor = calcFadeInOutFactor(ref rt, ref d, frequency);
            var result = shakeData.getNextVal(ref rt, ref d, frequency) * fadeInOutFactor;
            rt.cold.blob.Store(shakeData);
            return result;
        }

        static float calcFadeInOutFactor(ref TweenData tween, ref UnmanagedTweenData d, float frequency) {
            float animationDuration = d.animationDuration;
            var elapsedTimeInterpolating = d.easedInterpolationFactor * animationDuration;
            Assert.IsTrue(elapsedTimeInterpolating >= 0f);
            if (animationDuration == 0f) {
                return 0f;
            }
            Assert.IsTrue(animationDuration > 0f);
            float halfDuration = animationDuration * 0.5f;
            var oneShakeDuration = 1f / frequency;
            if (oneShakeDuration > halfDuration) {
                oneShakeDuration = halfDuration;
            }
            float fadeInDuration = oneShakeDuration * 0.5f;
            if (elapsedTimeInterpolating < fadeInDuration) {
                return Mathf.InverseLerp(0f, fadeInDuration, elapsedTimeInterpolating);
            }
            var fadeoutStartTime = animationDuration - oneShakeDuration;
            Assert.IsTrue(fadeoutStartTime > 0f, tween.cold.id);
            if (elapsedTimeInterpolating > fadeoutStartTime) {
                return Mathf.InverseLerp(animationDuration, fadeoutStartTime, elapsedTimeInterpolating);
            }
            return 1f;
        }
    }

    internal struct ShakeData {
        // 't' and 'prevInterpolationFactor' are full floats because the shake accumulates small per-frame deltas computed from them
        internal float t;
        internal float prevInterpolationFactor;
        internal int prevCyclesDone;
        ushort frequencyHalf;
        // shake points are stored as snorm8 normalized by the per-axis strength (stored in endValueOrDiff), so they're always in [-1, 1].
        // The points are random, so the rounding only picks a slightly different random point; the exact values (0 and ±1) stay exact
        sbyte fromX, fromY, fromZ, toX, toY, toZ;
        byte symmetryFactorPacked; // unorm8
        // Ease.Default means the falloff is disabled because Setup() replaces Ease.Default with Ease.Linear
        internal Ease falloffEase;
        internal Ease easeBetweenShakes;

        internal float frequency {
            get => UnityEngine.Mathf.HalfToFloat(frequencyHalf);
            set {
                ushort half = UnityEngine.Mathf.FloatToHalf(Mathf.Min(value, 65504f));
                if (value > 0f && half == 0) {
                    half = 1; // the frequency must stay positive
                }
                frequencyHalf = half;
            }
        }
        internal Vector3 from {
            get => new Vector3(fromX / Utils.snorm8Scale, fromY / Utils.snorm8Scale, fromZ / Utils.snorm8Scale);
            set {
                fromX = Utils.PackSnorm8(value.x);
                fromY = Utils.PackSnorm8(value.y);
                fromZ = Utils.PackSnorm8(value.z);
            }
        }
        internal Vector3 to {
            get => new Vector3(toX / Utils.snorm8Scale, toY / Utils.snorm8Scale, toZ / Utils.snorm8Scale);
            set {
                toX = Utils.PackSnorm8(value.x);
                toY = Utils.PackSnorm8(value.y);
                toZ = Utils.PackSnorm8(value.z);
            }
        }
        internal float symmetryFactor {
            get => symmetryFactorPacked / (float)byte.MaxValue;
            set => symmetryFactorPacked = (byte)Mathf.RoundToInt(Mathf.Clamp01(value) * byte.MaxValue);
        }

        internal void Setup(ShakeSettings settings, ref TweenData rt, ref UnmanagedTweenData d, object target) {
            d.isPunch = settings.isPunch;
            symmetryFactor = Mathf.Clamp01(1 - settings.asymmetry);
            {
                var _strength = settings.strength;
                if (float.IsNaN(_strength.x) || float.IsNaN(_strength.y) || float.IsNaN(_strength.z)) {
                    Debug.LogError($"Shake's strength is invalid: {_strength}. Using 0 instead of NaN components.", target as Object);
                    _strength = new Vector3(float.IsNaN(_strength.x) ? 0f : _strength.x, float.IsNaN(_strength.y) ? 0f : _strength.y, float.IsNaN(_strength.z) ? 0f : _strength.z);
                }
                if (_strength == default) {
                    Debug.LogError("Shake's strength is (0, 0, 0).");
                }
                // shakes don't use endValueOrDiff, so it stores the strength to keep ShakeData small
                rt.endValueOrDiff.CopyFrom(ref _strength);
            }
            {
                var _frequency = settings.frequency;
                if (!(_frequency > 0f) || float.IsInfinity(_frequency)) { // also catches NaN
                    Debug.LogError($"Shake's frequency should be > 0f, but was {_frequency}.", target as Object);
                    _frequency = ShakeSettings.defaultFrequency;
                }
                frequency = _frequency;
            }
            {
                if (settings.enableFalloff) {
                    var _falloffEase = settings.falloffEase;
                    var _customStrengthOverTime = settings.strengthOverTime;
                    if (_falloffEase == Ease.Default) {
                        _falloffEase = Ease.Linear;
                    }
                    if (_falloffEase == Ease.Custom) {
                        if (_customStrengthOverTime == null || !TweenSettings.ValidateCustomCurve(_customStrengthOverTime)) {
                            Debug.LogError($"Shake falloff is Ease.Custom, but {nameof(ShakeSettings.strengthOverTime)} is not configured correctly. Using Ease.Linear instead.", target as Object);
                            _falloffEase = Ease.Linear;
                        }
                    }
                    falloffEase = _falloffEase;
                    rt.cold.shakeStrengthOverTime = _customStrengthOverTime;
                } else {
                    falloffEase = Ease.Default;
                }
            }
            {
                var _easeBetweenShakes = settings.easeBetweenShakes;
                if (_easeBetweenShakes == Ease.Custom) {
                    Debug.LogError($"{nameof(ShakeSettings.easeBetweenShakes)} doesn't support Ease.Custom.", target as Object);
                    _easeBetweenShakes = Ease.OutQuad;
                }
                if (_easeBetweenShakes == Ease.Default) {
                    _easeBetweenShakes = PrimeTweenManager.defaultShakeEase;
                }
                easeBetweenShakes = _easeBetweenShakes;
            }
            onCycleComplete(ref rt, ref d);
        }

        internal void onCycleComplete(ref TweenData rt, ref UnmanagedTweenData d) {
            Assert.IsTrue(frequency > 0f);
            t = 0f;
            from = default;
            d.shakeSign = d.isPunch || PrimeTweenManager.random.NextDouble() < 0.5;
            to = generateShakePoint(ref rt, ref d);
        }

        static int getMainAxisIndex(Vector3 strengthByAxis) {
            int mainAxisIndex = -1;
            float maxStrength = float.NegativeInfinity;
            for (int i = 0; i < 3; i++) {
                var strength = Mathf.Abs(strengthByAxis[i]);
                if (strength > maxStrength) {
                    maxStrength = strength;
                    mainAxisIndex = i;
                }
            }
            Assert.IsTrue(mainAxisIndex >= 0);
            return mainAxisIndex;
        }

        internal Vector3 getNextVal(ref TweenData rt, ref UnmanagedTweenData d, float _frequency) {
            var interpolationFactor = d.easedInterpolationFactor;
            Assert.IsTrue(interpolationFactor <= 1);

            int cyclesDiff = d.getCyclesDone() - prevCyclesDone;
            prevCyclesDone = d.getCyclesDone();
            if (interpolationFactor == 0f || (cyclesDiff > 0 && d.getCyclesDone() != d.cyclesTotal)) {
                onCycleComplete(ref rt, ref d);
                prevInterpolationFactor = interpolationFactor;
            }

            float animationDuration = d.animationDuration;
            var dt = (interpolationFactor - prevInterpolationFactor) * animationDuration;
            prevInterpolationFactor = interpolationFactor;

            var strengthOverTime = calcStrengthOverTime(interpolationFactor, ref rt);
            var frequencyFactor = Mathf.Clamp01(strengthOverTime * 3f); // handpicked formula that describes the relationship between strength and frequency

            // The initial velocity should twice as big because the first shake starts from zero (twice as short as total range).
            var elapsedTimeInterpolating = d.easedInterpolationFactor * animationDuration;
            var halfShakeDuration = 0.5f / _frequency;
            float iniVelFactor = elapsedTimeInterpolating < halfShakeDuration ? 2f : 1f;

            t += _frequency * dt * frequencyFactor * iniVelFactor;
            if (t < 0f || t >= 1f) {
                d.shakeSign = !d.shakeSign;
                if (t < 0f) {
                    t = 1f;
                    to = from;
                    from = generateShakePoint(ref rt, ref d);
                } else {
                    t = 0f;
                    from = to;
                    to = generateShakePoint(ref rt, ref d);
                }
            }

            var _from = from;
            var _to = to;
            var strengthPerAxis = rt.endValueOrDiff.vector3;
            var easedT = StandardEasing.Evaluate(t, easeBetweenShakes);
            Vector3 result = default;
            for (int i = 0; i < 3; i++) {
                result[i] = Mathf.Lerp(_from[i], _to[i], easedT) * strengthPerAxis[i] * strengthOverTime;
            }
            return result;
        }

        Vector3 generateShakePoint(ref TweenData rt, ref UnmanagedTweenData d) {
            var strengthPerAxis = rt.endValueOrDiff.vector3;
            var mainAxisIndex = getMainAxisIndex(strengthPerAxis);
            var _symmetryFactor = symmetryFactor;
            Vector3 result = default;
            float signFloat = d.shakeSign ? 1f : -1f;
            for (int i = 0; i < 3; i++) {
                var strength = strengthPerAxis[i];
                float val;
                if (d.isPunch) {
                    val = clampBySymmetryFactor(strength * signFloat, strength, _symmetryFactor);
                } else {
                    val = i == mainAxisIndex ? calcMainAxisEndVal(signFloat, strength, _symmetryFactor) : calcNonMainAxisEndVal(strength, _symmetryFactor);
                }
                result[i] = strength == 0f ? 0f : val / strength;
            }
            return result;
        }

        float calcStrengthOverTime(float interpolationFactor, ref TweenData rt) {
            if (falloffEase == Ease.Default) {
                return 1;
            }
            if (falloffEase != Ease.Custom) {
                return 1 - StandardEasing.Evaluate(interpolationFactor, falloffEase);
            }
            var customStrengthOverTime = rt.cold.shakeStrengthOverTime as AnimationCurve;
            Assert.IsNotNull(customStrengthOverTime);
            return customStrengthOverTime.Evaluate(interpolationFactor);
        }

        static float calcMainAxisEndVal(float velocity, float strength, float symmetryFactor) {
            float result = Mathf.Sign(velocity) * strength * RandomRange(0.6f, 1f); // doesn't matter if we're using strength or its abs because velocity alternates
            return clampBySymmetryFactor(result, strength, symmetryFactor);
        }

        static float clampBySymmetryFactor(float val, float strength, float symmetryFactor) {
            if (strength > 0) {
                return Mathf.Clamp(val, -strength * symmetryFactor, strength);
            }
            return Mathf.Clamp(val, strength, -strength * symmetryFactor);
        }

        static float calcNonMainAxisEndVal(float strength, float symmetryFactor) {
            if (strength > 0) {
                return RandomRange(-strength * symmetryFactor, strength);
            }
            return RandomRange(strength, -strength * symmetryFactor);
        }

        static float RandomRange(float minInclusive, float max) {
            double val = PrimeTweenManager.random.NextDouble();
            return (float)(minInclusive + val * (max - minInclusive));
        }

        internal static bool TryTakeStartValueFromOtherShake(ref TweenData newTween, ref UnmanagedTweenData newTweenData) {
            if (!Utils.IsShake(newTweenData.tweenType)) {
                return false;
            }
            var shakeTransform = newTween.target as Transform;
            if (shakeTransform == null) {
                return false;
            }
            var shakes = PrimeTweenManager.Instance.shakes;
            var key = (shakeTransform, newTweenData.tweenType);
            if (!shakes.TryGetValue(key, out var data)) {
                var startValue = Utils.GetAnimatedValue(newTween.target, newTweenData.tweenType, ref newTween.cold.blob);
                shakes.Add(key, (startValue, 1));
                return false;
            }
            Assert.IsTrue(data.count >= 1);
            newTweenData.startValue = data.startValue;
            // Debug.Log($"tryTakeStartValueFromOtherShake {data.startValue.vector3}");
            data.count++;
            shakes[key] = data;
            return true;
        }

        internal static void Reset(object target, TweenType tweenType) {
            // 'is' instead of Unity's '!= null' because the entry of a destroyed Transform must be removed too
            if (target is Transform shakeTransform) {
                var key = (shakeTransform, tweenType);
                var shakes = PrimeTweenManager.Instance.shakes;
                if (shakes.TryGetValue(key, out var data)) {
                    // no key present if it's a ShakeCustom() with Transform target because custom shakes have startFromCurrent == false and aren't added to shakes dict
                    Assert.IsTrue(data.count >= 1);
                    data.count--;
                    if (data.count == 0) {
                        bool isRemoved = shakes.Remove(key);
                        Assert.IsTrue(isRemoved);
                    } else {
                        shakes[key] = data;
                    }
                }
            }
        }
    }
}
