// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable UnusedMember.Global
// ReSharper disable UnusedMethodReturnValue.Global
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using JetBrains.Annotations;
using UnityEngine;
using TweenType = PrimeTween.TweenAnimation.TweenType;

// p1 todo support color gradient
namespace PrimeTween {
    public partial struct Tween {
        /// <summary>Returns the number of alive tweens.</summary>
        /// <param name="onTarget">If specified, returns the number of running tweens on the target. Please note: if the target is specified, this method call has O(n) complexity where n is the total number of running tweens.</param>
        public static int GetTweensCount([CanBeNull] object onTarget = null) {
            PrimeTweenManager.EnsureRunningOnMainThread();
            var manager = PrimeTweenManager.Instance;
            if (onTarget == null && manager.updateDepth == 0) {
                int result = manager.tweensCount;
                #if PRIME_TWEEN_SAFETY_CHECKS && UNITY_ASSERTIONS
                Assert.AreEqual(result, PrimeTweenManager.ProcessAll(null, _ => true, true));
                #endif
                return result;
            }
            return PrimeTweenManager.ProcessAll(onTarget, _ => true, true); // call ProcessAll to filter null tweens
        }

        #if PRIME_TWEEN_EXPERIMENTAL
        public static int GetTweensCapacity() {
            PrimeTweenManager.EnsureRunningOnMainThread();
            var instance = PrimeTweenConfig.Instance;
            if (instance == null) {
                return PrimeTweenManager.customInitialCapacity;
            }
            return instance.currentPoolCapacity;
        }

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom(Double startValue, Double endValue, float duration, [NotNull] Action<Double> onValueChange, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => Custom(new TweenSettings<Double>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)), onValueChange);

        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween Custom(Double startValue, Double endValue, TweenSettings settings, [NotNull] Action<Double> onValueChange) => Custom(new TweenSettings<Double>(startValue, endValue, settings), onValueChange);

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom(TweenSettings<Double> settings, [NotNull] Action<Double> onValueChange)
            => CustomGeneric(PrimeTweenManager.dummyTarget, new NoTargetNoPayload(), settings.ToContainer(), onValueChange, null, TweenType.CustomDouble);

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom<T>([NotNull] T target, Double startValue, Double endValue, float duration, [NotNull] Action<T, Double> onValueChange, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false) where T : class
            => Custom(target, new TweenSettings<Double>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)), onValueChange);

        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween Custom<T>([NotNull] T target, Double startValue, Double endValue, TweenSettings settings, [NotNull] Action<T, Double> onValueChange) where T : class
            => Custom(target, new TweenSettings<Double>(startValue, endValue, settings), onValueChange);

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom<T>([NotNull] T target, TweenSettings<Double> settings, [NotNull] Action<T, Double> onValueChange) where T : class
            => CustomGeneric(target, new NoPayload(), settings.ToContainer(), onValueChange, null, TweenType.CustomDouble);

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom<T, TPayload>([NotNull] T target, TPayload payload, TweenSettings<Double> settings, [NotNull] Action<T, TPayload, Double> onValueChange) where T : class where TPayload : unmanaged
            => CustomGeneric(target, payload, settings.ToContainer(), onValueChange, null, TweenType.CustomDouble);

        public static Tween CustomAdditive<T>([NotNull] T target, Double deltaValue, TweenSettings settings, [NotNull] Action<T, Double> onDeltaChange) where T : class
            => CustomGeneric(target, new AdditivePayload(), new TweenSettings<Double>(default, deltaValue, settings).ToContainer(), onDeltaChange, null, TweenType.CustomDouble);
        #endif

        /// <summary>Stops all tweens and sequences.<br/>
        /// If <see cref="onTarget"/> is provided, stops only tweens on this target (stopping a tween inside a Sequence is not allowed).</summary>
        /// <returns>The number of stopped tweens.</returns>
        public static int StopAll([CanBeNull] object onTarget = null) {
            PrimeTweenManager.EnsureRunningOnMainThread();
            var result = PrimeTweenManager.ProcessAll(onTarget, tween => {
                ref var d = ref tween.data;
                if (d.isInSequence) {
                    if (d.IsMainSequenceRoot()) {
                        new Sequence(tween.sequence).Stop();
                    }
                    // do nothing with nested tween or sequence. The main sequence root will process it
                } else {
                    tween.managedData.Kill(ref d);
                }
                return true;
            }, false);
            ForceUpdateManagerIfTargetIsNull(onTarget);
            return result;
        }

        /// <summary>Completes all tweens and sequences.<br/>
        /// If <see cref="onTarget"/> is provided, completes only tweens on this target (completing a tween inside a Sequence is not allowed).</summary>
        /// <returns>The number of completed tweens.</returns>
        public static int CompleteAll([CanBeNull] object onTarget = null) {
            PrimeTweenManager.EnsureRunningOnMainThread();
            var manager = PrimeTweenManager.Instance;
            if (manager.updateDepth != 0) {
                manager.completeAllRequested = true;
                manager.completeAllRequestedTarget = onTarget;
                return onTarget == null ? manager.tweensCount : GetTweensCount(onTarget);
            }

            manager.AddNewTweens(_UpdateType.Update);
            manager.AddNewTweens(_UpdateType.LateUpdate);
            manager.AddNewTweens(_UpdateType.FixedUpdate);
            #if PRIME_TWEEN_EXPERIMENTAL
            manager.AddNewTweens(_UpdateType.Manual);
            #endif
            var result = PrimeTweenManager.ProcessAll(onTarget, tween => {
                ref var d = ref tween.data;
                if (d.isInSequence) {
                    if (d.IsMainSequenceRoot()) {
                        new Sequence(tween.sequence).Complete();
                    }
                    // do nothing with nested tween or sequence. The main sequence root will process it
                } else {
                    new Tween(tween).Complete();
                }
                return true;
            }, false, onlyRunning: true);
            ForceUpdateManagerIfTargetIsNull(onTarget);
            return result;
        }

        static void ForceUpdateManagerIfTargetIsNull([CanBeNull] object onTarget) {
            if (onTarget == null) {
                var manager = PrimeTweenManager.Instance;
                if (manager != null) {
                    if (manager.updateDepth == 0) {
                        manager.UpdateTweens(_UpdateType.Update, 0f, 0f);
                        manager.UpdateTweens(_UpdateType.LateUpdate, 0f, 0f);
                        manager.UpdateTweens(_UpdateType.FixedUpdate, 0f, 0f);

                        // user's onComplete can create new tweens, so calling UpdateTweens copies new tweens into running tweens array
                        // Assert.AreEqual(0, manager.tweensUpdate.Count);
                        // Assert.AreEqual(0, manager.tweensLateUpdate.Count); // LateUpdate adds new tweens after update
                        // Assert.AreEqual(0, manager.tweensFixedUpdate.Count);
                    }
                }
            }
        }

        /// <summary>Pauses/unpauses all tweens and sequences.<br/>
        /// If <see cref="onTarget"/> is provided, pauses/unpauses only tweens on this target (pausing/unpausing a tween inside a Sequence is not allowed).</summary>
        /// <returns>The number of paused/unpaused tweens.</returns>
        public static int SetPausedAll(bool isPaused, [CanBeNull] object onTarget = null) {
            PrimeTweenManager.EnsureRunningOnMainThread();
            if (isPaused) {
                return PrimeTweenManager.ProcessAll(onTarget, tween => {
                    if (!tween.data.canManipulate()) {
                        return false; // the parent Sequence controls the pause of nested animations. A paused nested Sequence stops updating its children
                    }
                    if (tween.data.isInSequence && tween.FindMainSequence().data.IsCompleting) {
                        return false; // see Sequence.Complete()
                    }
                    tween.data.TryRollBackJobUpdate();
                    return tween.data.trySetPause(true);
                }, false);
            }
            return PrimeTweenManager.ProcessAll(onTarget, tween => {
                return tween.data.trySetPause(false);
            }, false);
        }

        /// <summary>Please note: delay may outlive the caller (the calling UnityEngine.Object may already be destroyed).
        /// When using this overload, it's user's responsibility to ensure that <see cref="onComplete"/> is safe to execute once the delay is finished.
        /// It's preferable to use the <see cref="Delay{T}"/> overload because it checks if the UnityEngine.Object target is still alive before calling the <see cref="onComplete"/>.</summary>
        /// <param name="warnIfTargetDestroyed">https://github.com/KyryloKuzyk/PrimeTween/discussions/4</param>
        public static Tween Delay(float duration, [CanBeNull] Action onComplete = null, bool useUnscaledTime = false, bool? warnIfTargetDestroyed = null) {
            return DelayInternal(PrimeTweenManager.dummyTarget, duration, onComplete, useUnscaledTime, warnIfTargetDestroyed);
        }
        /// <param name="warnIfTargetDestroyed">https://github.com/KyryloKuzyk/PrimeTween/discussions/4</param>
        public static Tween Delay([NotNull] object target, float duration, [CanBeNull] Action onComplete = null, bool useUnscaledTime = false, bool? warnIfTargetDestroyed = null) {
            return DelayInternal(target, duration, onComplete, useUnscaledTime, warnIfTargetDestroyed);
        }
        static Tween DelayInternal([CanBeNull] object target, float duration, [CanBeNull] Action onComplete, bool useUnscaledTime, bool? warnIfTargetDestroyed) {
            var result = delay_internal(target, duration, useUnscaledTime);
            if (onComplete != null) {
                result?.tween.managedData.OnComplete(onComplete, warnIfTargetDestroyed);
            }
            return result ?? default;
        }

        /// <summary> This is the most preferable overload of all Delay functions:<br/>
        /// - It checks if UnityEngine.Object target is still alive before calling the <see cref="onComplete"/> callback.<br/>
        /// - It allows calling any method on <see cref="target"/> without producing garbage.</summary>
        /// <example>
        /// <code>
        /// Tween.Delay(this, duration: 1f, onComplete: _this =&gt; {
        ///     // Please note: we're using '_this' variable from the onComplete callback. Calling DoSomething() directly will implicitly capture 'this' variable (creating a closure) and generate garbage.
        ///     _this.DoSomething();
        /// });
        /// </code>
        /// </example>
        /// <param name="warnIfTargetDestroyed">https://github.com/KyryloKuzyk/PrimeTween/discussions/4</param>
        public static Tween Delay<T>([NotNull] T target, float duration, [NotNull] Action<T> onComplete, bool useUnscaledTime = false, bool? warnIfTargetDestroyed = null) where T : class {
            var maybeDelay = delay_internal(target, duration, useUnscaledTime);
            if (!maybeDelay.HasValue) {
                return default;
            }
            var delay = maybeDelay.Value;
            delay.tween.managedData.OnComplete(target, onComplete, warnIfTargetDestroyed);
            return delay;
        }

        /// <summary>Same as <see cref="Delay{T}(T,float,Action{T},bool,bool?)"/>, but also passes the <paramref name="payload"/> to the <paramref name="onComplete"/> callback without producing garbage.<br/>
        /// <typeparamref name="TPayload"/> can be any struct without reference type fields, up to 16 bytes.</summary>
        /// <param name="warnIfTargetDestroyed">https://github.com/KyryloKuzyk/PrimeTween/discussions/4</param>
        public static Tween Delay<T, TPayload>([NotNull] T target, TPayload payload, float duration, [NotNull] Action<T, TPayload> onComplete, bool useUnscaledTime = false, bool? warnIfTargetDestroyed = null) where T : class where TPayload : unmanaged {
            if (TweenData.CheckPayloadSize<TPayload>()) {
                var maybeDelay = delay_internal(target, duration, useUnscaledTime);
                if (maybeDelay.HasValue) {
                    var delay = maybeDelay.Value;
                    delay.tween.managedData.OnComplete(target, payload, onComplete, warnIfTargetDestroyed);
                    return delay;
                }
            }
            return default;
        }

        static Tween? delay_internal([CanBeNull] object target, float duration, bool useUnscaledTime) {
            PrimeTweenManager.CheckDuration(target, duration);
            return PrimeTweenManager.DelayWithoutDurationCheck(target, duration, useUnscaledTime, false);
        }

        public static Tween MaterialColor([NotNull] Material target, int propertyId, Color endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialColor(target, propertyId, new TweenSettings<Color>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialColor([NotNull] Material target, int propertyId, Color startValue, Color endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialColor(target, propertyId, new TweenSettings<Color>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialColor([NotNull] Material target, int propertyId, Color endValue, TweenSettings settings) => MaterialColor(target, propertyId, new TweenSettings<Color>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialColor([NotNull] Material target, int propertyId, Color startValue, Color endValue, TweenSettings settings) => MaterialColor(target, propertyId, new TweenSettings<Color>(startValue, endValue, settings));
        public static Tween MaterialColor([NotNull] Material target, int propertyId, TweenSettings<Color> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialColorProperty);

        public static Tween MaterialProperty([NotNull] Material target, int propertyId, float endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialProperty(target, propertyId, new TweenSettings<float>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, float startValue, float endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialProperty(target, propertyId, new TweenSettings<float>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, float endValue, TweenSettings settings) => MaterialProperty(target, propertyId, new TweenSettings<float>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, float startValue, float endValue, TweenSettings settings) => MaterialProperty(target, propertyId, new TweenSettings<float>(startValue, endValue, settings));
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, TweenSettings<float> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialProperty);

        public static Tween MaterialAlpha([NotNull] Material target, int propertyId, float endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialAlpha(target, propertyId, new TweenSettings<float>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialAlpha([NotNull] Material target, int propertyId, float startValue, float endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialAlpha(target, propertyId, new TweenSettings<float>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialAlpha([NotNull] Material target, int propertyId, float endValue, TweenSettings settings) => MaterialAlpha(target, propertyId, new TweenSettings<float>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialAlpha([NotNull] Material target, int propertyId, float startValue, float endValue, TweenSettings settings) => MaterialAlpha(target, propertyId, new TweenSettings<float>(startValue, endValue, settings));
        public static Tween MaterialAlpha([NotNull] Material target, int propertyId, TweenSettings<float> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialAlphaProperty);

        public static Tween MaterialTextureOffset([NotNull] Material target, int propertyId, Vector2 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialTextureOffset(target, propertyId, new TweenSettings<Vector2>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialTextureOffset([NotNull] Material target, int propertyId, Vector2 startValue, Vector2 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialTextureOffset(target, propertyId, new TweenSettings<Vector2>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialTextureOffset([NotNull] Material target, int propertyId, Vector2 endValue, TweenSettings settings) => MaterialTextureOffset(target, propertyId, new TweenSettings<Vector2>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialTextureOffset([NotNull] Material target, int propertyId, Vector2 startValue, Vector2 endValue, TweenSettings settings) => MaterialTextureOffset(target, propertyId, new TweenSettings<Vector2>(startValue, endValue, settings));
        public static Tween MaterialTextureOffset([NotNull] Material target, int propertyId, TweenSettings<Vector2> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialTextureOffset);

        public static Tween MaterialTextureScale([NotNull] Material target, int propertyId, Vector2 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialTextureScale(target, propertyId, new TweenSettings<Vector2>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialTextureScale([NotNull] Material target, int propertyId, Vector2 startValue, Vector2 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialTextureScale(target, propertyId, new TweenSettings<Vector2>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialTextureScale([NotNull] Material target, int propertyId, Vector2 endValue, TweenSettings settings) => MaterialTextureScale(target, propertyId, new TweenSettings<Vector2>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialTextureScale([NotNull] Material target, int propertyId, Vector2 startValue, Vector2 endValue, TweenSettings settings) => MaterialTextureScale(target, propertyId, new TweenSettings<Vector2>(startValue, endValue, settings));
        public static Tween MaterialTextureScale([NotNull] Material target, int propertyId, TweenSettings<Vector2> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialTextureScale);

        public static Tween MaterialProperty([NotNull] Material target, int propertyId, Vector4 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialProperty(target, propertyId, new TweenSettings<Vector4>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, Vector4 startValue, Vector4 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialProperty(target, propertyId, new TweenSettings<Vector4>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, Vector4 endValue, TweenSettings settings) => MaterialProperty(target, propertyId, new TweenSettings<Vector4>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, Vector4 startValue, Vector4 endValue, TweenSettings settings) => MaterialProperty(target, propertyId, new TweenSettings<Vector4>(startValue, endValue, settings));
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, TweenSettings<Vector4> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialPropertyVector4);


        static readonly System.Collections.Generic.Dictionary<int, int> textureIdTo_ST = new System.Collections.Generic.Dictionary<int, int>(10);
        internal static int GetMaterialSTPropId(int textureId, string textureName) {
            if (!textureIdTo_ST.TryGetValue(textureId, out int result)) {
                result = Shader.PropertyToID(textureName + "_ST");
                textureIdTo_ST.Add(textureId, result);
            }
            return result;
        }

        // No 'startFromCurrent' overload because euler angles animation should always have the startValue to prevent ambiguous results
        public static Tween EulerAngles([NotNull] Transform target, Vector3 startValue, Vector3 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => EulerAngles(target, new TweenSettings<Vector3>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween EulerAngles([NotNull] Transform target, Vector3 startValue, Vector3 endValue, TweenSettings settings) => EulerAngles(target, new TweenSettings<Vector3>(startValue, endValue, settings));
        public static Tween EulerAngles([NotNull] Transform target, TweenSettings<Vector3> settings) {
            ValidateEulerAnglesData(ref settings);
            return animate(target, ref settings, TweenType.EulerAngles);
        }

        public static Tween LocalEulerAngles([NotNull] Transform target, Vector3 startValue, Vector3 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => LocalEulerAngles(target, new TweenSettings<Vector3>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween LocalEulerAngles([NotNull] Transform target, Vector3 startValue, Vector3 endValue, TweenSettings settings) => LocalEulerAngles(target, new TweenSettings<Vector3>(startValue, endValue, settings));
        public static Tween LocalEulerAngles([NotNull] Transform target, TweenSettings<Vector3> settings) {
            ValidateEulerAnglesData(ref settings);
            return animate(target, ref settings, TweenType.LocalEulerAngles);
        }
        static void ValidateEulerAnglesData(ref TweenSettings<Vector3> settings) {
            if (settings.startFromCurrent) {
                settings.startFromCurrent = false;
                Debug.LogWarning("Animating euler angles from the current value may produce unexpected results because there is more than one way to represent the current rotation using Euler angles.\n" +
                                 "'" + nameof(TweenSettings<float>.startFromCurrent) + "' was ignored.\n" +
                                 "More info: https://docs.unity3d.com/ScriptReference/Transform-eulerAngles.html\n");
            }
        }

        // Called from TweenGenerated.cs
        public static Tween Scale([NotNull] Transform target, TweenSettings<float> uniformScaleSettings) {
            var remapped = new TweenSettings<Vector3>(uniformScaleSettings.startValue * Vector3.one, uniformScaleSettings.endValue * Vector3.one, uniformScaleSettings.settings) { startFromCurrent = uniformScaleSettings.startFromCurrent };
            return Scale(target, remapped);
        }
        public static Tween Rotation([NotNull] Transform target, TweenSettings<Vector3> eulerAnglesSettings) => Rotation(target, ToQuaternion(eulerAnglesSettings));
        public static Tween LocalRotation([NotNull] Transform target, TweenSettings<Vector3> localEulerAnglesSettings) => LocalRotation(target, ToQuaternion(localEulerAnglesSettings));
        static TweenSettings<Quaternion> ToQuaternion(TweenSettings<Vector3> s) => new TweenSettings<Quaternion>(Quaternion.Euler(s.startValue), Quaternion.Euler(s.endValue), s.settings) { startFromCurrent = s.startFromCurrent };
        #if TEXT_MESH_PRO_INSTALLED
        public static Tween TextMaxVisibleCharacters([NotNull] TMPro.TMP_Text target, TweenSettings<int> settings) {
            if (target != null) { // creating the tween reports the destroyed target
                var textInfo = Utils.GetTextInfo(target);
                if (textInfo == null) {
                    Debug.LogError("'TMPro.TMP_Text.textInfo' is null!");
                    return default;
                }
                int oldCount = textInfo.characterCount;
                target.ForceMeshUpdate();
                if (oldCount != textInfo.characterCount) {
                    Debug.LogWarning("Please call TMP_Text.ForceMeshUpdate() before animating maxVisibleCharacters.");
                }
            }
            var floatSettings = new TweenSettings<float>(settings.startValue, settings.endValue, settings.settings);
            return AnimateIntAsFloat(target, ref floatSettings, TweenType.TextMaxVisibleCharacters);
        }
        // p2 todo fix this correctly
        static Tween AnimateIntAsFloat(object target, ref TweenSettings<float> settings, TweenType tweenType) {
            if (PrimeTweenManager.Instance.isDestroyed) {
                return default;
            }
            var tween = PrimeTweenManager.FetchTween(settings.settings._updateType);
            ref var rt = ref tween.managedData;
            ref var d = ref tween.data;

            d.startValue.CopyFrom(ref settings.startValue);
            rt.endValueOrDiff.CopyFrom(ref settings.endValue);
            tween.Setup(target, ref settings.settings, settings.startFromCurrent, tweenType, ref rt, ref d);
            return PrimeTweenManager.Animate(ref rt, ref d);
        }
        public static Tween TextMaxVisibleCharactersNormalized([NotNull] TMPro.TMP_Text target, TweenSettings<float>   settings) => animate(target, ref settings, TweenType.TextMaxVisibleCharactersNormalized);
        #endif

        // not generated automatically because GlobalTimeScale() should have 'useUnscaledTime: true'
        public static Tween GlobalTimeScale(Single endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0)
            => GlobalTimeScale(new TweenSettings<float>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, true)));
        public static Tween GlobalTimeScale(Single startValue, Single endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0)
            => GlobalTimeScale(new TweenSettings<float>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, true)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween GlobalTimeScale(Single endValue, TweenSettings settings) => GlobalTimeScale(new TweenSettings<float>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween GlobalTimeScale(Single startValue, Single endValue, TweenSettings settings) => GlobalTimeScale(new TweenSettings<float>(startValue, endValue, settings));
        public static Tween GlobalTimeScale(TweenSettings<float> settings) {
            clampTimescale(ref settings.startValue);
            clampTimescale(ref settings.endValue);
            if (!settings.settings.useUnscaledTime) {
                Debug.LogWarning("Setting " + nameof(TweenSettings.useUnscaledTime) + " to true to animate Time.timeScale correctly.");
                settings.settings.useUnscaledTime = true;
            }
            return animate(PrimeTweenManager.dummyTarget, ref settings, TweenType.GlobalTimeScale);

            void clampTimescale(ref float value) {
                if (value < 0) {
                    Debug.LogError($"timeScale should be >= 0, but was {value}");
                    value = 0;
                }
            }
        }

        public static Tween TweenTimeScale(Tween tween, TweenSettings<float> settings) => AnimateTimeScale(tween, settings, TweenType.TweenTimeScale);
        static Tween AnimateTimeScale(Tween tween, TweenSettings<float> settings, TweenType tweenType) {
            if (!tween.TryManipulate()) {
                return default;
            }
            if (float.IsNaN(settings.endValue) || !settings.startFromCurrent && float.IsNaN(settings.startValue)) {
                Debug.LogError($"Invalid {nameof(timeScale)}: startValue {settings.startValue}, endValue {settings.endValue}.");
                return default;
            }
            ClampTimeScale(ref settings.startValue);
            ClampTimeScale(ref settings.endValue);
            if (tween.tween.data.HasWait) {
                if (!ValidateWaitTimeScale(settings.endValue) || !ValidateWaitTimeScale(settings.startValue)) {
                    return default;
                }
            }
            var result = animate(tween.tween, ref settings, tweenType);
            Assert.IsTrue(result.isAliveInternal);
            result.tween.blob.Store(new TargetTweenIdPayload { id = tween.id });
            return result;
        }
        public static Tween TweenTimeScale(Sequence sequence, TweenSettings<float> settings) => AnimateTimeScale(sequence.root, settings, TweenType.TweenTimeScaleSequence);

        public static Tween RotationAtSpeed([NotNull] Transform target, Vector3 endValue, float averageAngularSpeed, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => RotationAtSpeed(target, new TweenSettings<Vector3>(endValue, new TweenSettings(averageAngularSpeed, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween RotationAtSpeed([NotNull] Transform target, Vector3 startValue, Vector3 endValue, float averageAngularSpeed, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => RotationAtSpeed(target, new TweenSettings<Vector3>(startValue, endValue, new TweenSettings(averageAngularSpeed, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        static Tween RotationAtSpeed([NotNull] Transform target, TweenSettings<Vector3> settingsVector3) {
            var settings = ToQuaternion(settingsVector3);
            var speed = settings.settings.duration;
            if (speed <= 0) {
                Debug.LogError($"Invalid speed provided to the Tween.{nameof(RotationAtSpeed)}() method: {speed}.");
                return default;
            }
            if (settings.startFromCurrent) {
                settings.startFromCurrent = false;
                settings.startValue = target != null ? target.rotation : Quaternion.identity; // creating the tween reports the destroyed target
            }
            settings.settings.duration = Extensions.CalcDistance(settings.startValue, settings.endValue) / speed;
            return Rotation(target, settings);
        }

        public static Tween LocalRotationAtSpeed([NotNull] Transform target, Vector3 endValue, float averageAngularSpeed, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => LocalRotationAtSpeed(target, new TweenSettings<Vector3>(endValue, new TweenSettings(averageAngularSpeed, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween LocalRotationAtSpeed([NotNull] Transform target, Vector3 startValue, Vector3 endValue, float averageAngularSpeed, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => LocalRotationAtSpeed(target, new TweenSettings<Vector3>(startValue, endValue, new TweenSettings(averageAngularSpeed, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        static Tween LocalRotationAtSpeed([NotNull] Transform target, TweenSettings<Vector3> settingsVector3) {
            var settings = ToQuaternion(settingsVector3);
            var speed = settings.settings.duration;
            if (speed <= 0) {
                Debug.LogError($"Invalid speed provided to the Tween.{nameof(LocalRotationAtSpeed)}() method: {speed}.");
                return default;
            }
            if (settings.startFromCurrent) {
                settings.startFromCurrent = false;
                settings.startValue = target != null ? target.localRotation : Quaternion.identity; // creating the tween reports the destroyed target
            }
            settings.settings.duration = Extensions.CalcDistance(settings.startValue, settings.endValue) / speed;
            return LocalRotation(target, settings);
        }

        #if !UNITY_2019_1_OR_NEWER || PHYSICS_MODULE_INSTALLED
        public static Tween RigidbodyMoveRotation(Rigidbody target, TweenSettings<Vector3> eulerAnglesSettings) => RigidbodyMoveRotation(target, ToQuaternion(eulerAnglesSettings));
        #endif

        static Tween AnimateMaterial([CanBeNull] object target, MaterialPayload materialPayload, TweenSettings<TweenAnimation.ValueWrapper> settings, TweenType tweenType) {
            if (PrimeTweenManager.Instance.isDestroyed) {
                return default;
            }
            int materialIndex = materialPayload.materialIndex;
            #if UNITY_ASSERTIONS
            int propId = materialPayload.propId;
            if (target is Material material && material != null && !Utils.IsValidMaterialProperty(tweenType, target, propId, materialIndex)) {
                Debug.LogWarning($"Material doesn't have a property with id '{propId}'.", material);
            }
            if (target is Renderer renderer && renderer != null && !Utils.IsValidMaterialProperty(tweenType, target, propId, materialIndex)) {
                Debug.LogWarning($"Renderer's material doesn't have a property with id '{propId}', materialIndex: {materialIndex}.", renderer);
            }
            #endif
            var tween = PrimeTweenManager.FetchTween(settings.settings._updateType);
            ref var d = ref tween.data;
            ref var rt = ref tween.managedData;
            d.startValue = settings.startValue;
            rt.endValueOrDiff = settings.endValue;
            tween.blob.Store(materialPayload);
            tween.Setup(target, ref settings.settings, settings.startFromCurrent, tweenType, ref rt, ref d);
            return PrimeTweenManager.Animate(ref rt, ref d);
        }

        static Tween AnimateGeneric(object target, ref TweenSettings<TweenAnimation.ValueWrapper> settings, TweenType tweenType) {
            var propType = Utils.TweenTypeToTweenData(tweenType).Item1;
            switch (propType) {
                case PropType.Color: {
                    var s = new TweenSettings<Color>(settings.startValue.color, settings.endValue.color, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Vector2: {
                    var s = new TweenSettings<Vector2>(settings.startValue.vector2, settings.endValue.vector2, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Float: {
                    var s = new TweenSettings<float>(settings.startValue.single, settings.endValue.single, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Vector3: {
                    var s = new TweenSettings<Vector3>(settings.startValue.vector3, settings.endValue.vector3, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Vector4: {
                    var s = new TweenSettings<Vector4>(settings.startValue.vector4, settings.endValue.vector4, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Quaternion: {
                    var s = new TweenSettings<Quaternion>(settings.startValue.quaternion, settings.endValue.quaternion, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Rect: {
                    var s = new TweenSettings<Rect>(settings.startValue.rect, settings.endValue.rect, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.ColorGradient: {
                    var s = new TweenSettings<float>(settings.startValue.single, settings.endValue.single, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                default: throw new Exception(propType.ToString());
            }
        }

        /// <summary>Animates custom value. Accessing outside variables from the callbacks creates a closure that allocates garbage. To animate without allocations, use <paramref name="target"/> and optional <paramref name="payload"/>.</summary>
        /// <param name="target">An optional object passed to <paramref name="onValueChange"/> and <paramref name="getCurrentValue"/>.</param>
        /// <param name="payload">An optional struct passed to <paramref name="onValueChange"/> and <paramref name="getCurrentValue"/> without producing garbage. Can be any struct without reference type fields, up to 16 bytes.</param>
        /// <param name="onValueChange">Use to set the custom value.</param>
        /// <param name="getCurrentValue">Use to get the current custom value. Provide it to support <see cref="TweenSettings{T}.startFromCurrent"/> on custom tweens.</param>
        /// <example><code>
        /// Tween.Custom(this, new TweenSettings&lt;float&gt;(endValue: 1f, duration: 1f),
        ///     onValueChange: static (_this, val) =&gt; _this.value = val,
        ///     getCurrentValue: static _this =&gt; _this.value);
        /// </code>
        /// Use the payload to avoid capturing variables in lambdas:
        /// <code>
        /// public static Tween AnimateMaterialColor(Material target, int propertyId, TweenSettings&lt;Color&gt; settings) {
        ///     return Tween.Custom(target, propertyId, settings,
        ///         onValueChange: static (m, id, color) =&gt; m.SetColor(id, color),
        ///         getCurrentValue: static (m, id) =&gt; m.GetColor(id));
        /// }
        /// </code></example>
        static Tween CustomGeneric<T, TPayload>([NotNull] T target, TPayload payload, TweenSettings<TweenAnimation.ValueWrapper> settings, [NotNull] object onValueChange, [CanBeNull] object getCurrentValue, TweenType tweenType) where T : class where TPayload : unmanaged {
            if (onValueChange == null) {
                Debug.LogError(Constants.onValueChangeNullError);
                return default;
            }
            if (settings.startFromCurrent && getCurrentValue == null) {
                Debug.LogWarning(Constants.customTweensDontSupportStartFromCurrentWarning);
            }
            if (PrimeTweenManager.Instance.isDestroyed || !TweenData.CheckPayloadSize<TPayload>()) {
                return default;
            }
            var tween = PrimeTweenManager.FetchTween(settings.settings._updateType);
            ref var rt = ref tween.managedData;
            ref var d = ref tween.data;

            d.startValue = settings.startValue;
            rt.endValueOrDiff = settings.endValue;
            if (IsAdditive<TPayload>()) {
                d.isAdditive = true;
                AdditivePayload iniPayload = default;
                if (tweenType == TweenType.CustomQuaternion) {
                    iniPayload.prevVal.w = 1f; // Quaternion.identity
                }
                tween.blob.Store(iniPayload);
            } else if (HasCustomPayload<TPayload>()) {
                tween.blob.Store(payload);
            }

            if (getCurrentValue != null) {
                tween.customGetter = getCurrentValue;
                tween.customGetterInvoker = (OnValueChangeDelegate)((ref TweenData rt2, ref UnmanagedTweenData d2) => {
                    var _getter = rt2.cold.customGetter;
                    var _target = rt2.target as T;
                    TPayload _payload = HasCustomPayload<TPayload>() ? rt2.cold.blob.Load<TPayload>() : default;
                    switch (d2.propType) {
                        case PropType.Float:      d2.startValue = InvokeCustomGetter<T, TPayload, float>     (_getter, _target, _payload).ToContainer(); break;
                        case PropType.Color:      d2.startValue = InvokeCustomGetter<T, TPayload, Color>     (_getter, _target, _payload).ToContainer(); break;
                        case PropType.Vector2:    d2.startValue = InvokeCustomGetter<T, TPayload, Vector2>   (_getter, _target, _payload).ToContainer(); break;
                        case PropType.Vector3:    d2.startValue = InvokeCustomGetter<T, TPayload, Vector3>   (_getter, _target, _payload).ToContainer(); break;
                        case PropType.Vector4:    d2.startValue = InvokeCustomGetter<T, TPayload, Vector4>   (_getter, _target, _payload).ToContainer(); break;
                        case PropType.Quaternion: d2.startValue = InvokeCustomGetter<T, TPayload, Quaternion>(_getter, _target, _payload).ToContainer(); break;
                        case PropType.Rect:       d2.startValue = InvokeCustomGetter<T, TPayload, Rect>      (_getter, _target, _payload).ToContainer(); break;
                        default: throw new Exception(d2.propType.ToString());
                    }
                });
            }

            tween.customOnValueChange = onValueChange;
            tween.onValueChange = (ref TweenData rt2, ref UnmanagedTweenData d2) => {
                if (d2.isUpdating) {
                    Debug.LogError(Constants.recursiveCallError);
                    return;
                }

                var _target = rt2.target as T;
                object _onValueChange = rt2.cold.customOnValueChange;
                try {
                    d2.isUpdating = true;
                    if (IsAdditive<TPayload>()) {
                        // additive tweens report the delta since the previous update, so (val, prevVal) = (val - prevVal, val)
                        var additivePayload = rt2.cold.blob.Load<AdditivePayload>();
                        ref var prev = ref additivePayload.prevVal;
                        switch (d2.propType) {
                            case PropType.Float:      { var val = TweenData.FloatVal     (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff); (val, prev.single)     = (val - prev.single, val);                         InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), val); break; }
                            case PropType.Color:      { var val = TweenData.ColorVal     (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff); (val, prev.color)      = (val - prev.color, val);                          InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), val); break; }
                            case PropType.Vector2:    { var val = TweenData.Vector2Val   (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff); (val, prev.vector2)    = (val - prev.vector2, val);                        InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), val); break; }
                            case PropType.Vector3:    { var val = TweenData.Vector3Val   (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff); (val, prev.vector3)    = (val - prev.vector3, val);                        InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), val); break; }
                            case PropType.Vector4:    { var val = TweenData.Vector4Val   (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff); (val, prev.vector4)    = (val - prev.vector4, val);                        InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), val); break; }
                            case PropType.Double:     { var val = TweenData.DoubleVal    (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff); (val, prev.DoubleVal)  = (val - prev.DoubleVal, val);                      InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), val); break; }
                            case PropType.Quaternion: { var val = TweenData.QuaternionVal(d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff); (val, prev.quaternion) = (Quaternion.Inverse(prev.quaternion) * val, val); InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), val); break; }
                            case PropType.Rect:       { var val = TweenData.RectVal      (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff); (val, prev.rect)       = (new Rect(val.x - prev.x, val.y - prev.y, val.width - prev.z, val.height - prev.w), val);
                                                                                                                                                                                                                                       InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), val); break; }
                            default: throw new Exception(d2.propType.ToString());
                        }
                        rt2.cold.blob.Store(additivePayload);
                    } else {
                        TPayload _payload = HasCustomPayload<TPayload>() ? rt2.cold.blob.Load<TPayload>() : default;
                        switch (d2.propType) {
                            case PropType.Float:      InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.FloatVal     (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Color:      InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.ColorVal     (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Vector2:    InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.Vector2Val   (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Vector3:    InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.Vector3Val   (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Vector4:    InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.Vector4Val   (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Double:     InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.DoubleVal    (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Quaternion: InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.QuaternionVal(d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Rect:       InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.RectVal      (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            default: throw new Exception(d2.propType.ToString());
                        }
                    }
                } finally {
                    d2.isUpdating = false;
                }
            };

            tween.Setup(target, ref settings.settings, settings.startFromCurrent && getCurrentValue != null, tweenType, ref rt, ref d);
            return PrimeTweenManager.Animate(ref rt, ref d);
        }

        internal struct NoPayload { }
        internal struct NoTargetNoPayload { }
        internal struct AdditivePayload {
            internal TweenAnimation.ValueWrapper prevVal;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool HasCustomPayload<TPayload>() => typeof(TPayload) != typeof(NoPayload) && typeof(TPayload) != typeof(NoTargetNoPayload) && typeof(TPayload) != typeof(AdditivePayload);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool IsAdditive<TPayload>() => typeof(TPayload) == typeof(AdditivePayload);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static TVal InvokeCustomGetter<T, TPayload, TVal>(object getter, T target, TPayload payload) where T : class where TPayload : unmanaged {
            if (typeof(TPayload) == typeof(NoPayload)) {
                return (getter as Func<T, TVal>)(target);
            } else if (typeof(TPayload) == typeof(NoTargetNoPayload)) {
                return (getter as Func<TVal>)();
            } else {
                return (getter as Func<T, TPayload, TVal>)(target, payload);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static void InvokeCustomOnValueChange<T, TPayload, TVal>(object onValueChange, T target, TPayload payload, TVal val) where T : class where TPayload : unmanaged {
            if (typeof(TPayload) == typeof(NoPayload) || typeof(TPayload) == typeof(AdditivePayload)) {
                (onValueChange as Action<T, TVal>)(target, val);
            } else if (typeof(TPayload) == typeof(NoTargetNoPayload)) {
                (onValueChange as Action<TVal>)(val);
            } else {
                (onValueChange as Action<T, TPayload, TVal>)(target, payload, val);
            }
        }
    }
}
